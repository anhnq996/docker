<?php

namespace Illuminate\Database\Events;

class MigrationsEnded extends MigrationsEvent
{
    //
}
